<?php
/**
 * PTENit & Order Boss — Secure Server Data Synchronization & Persistence Engine
 * Supports standard cPanel Apache & PHP 7.4 / 8.0 / 8.1 / 8.2 / 8.3 / 8.4
 * Stores data safely in server_data/*.json (Protected from direct web access)
 */

// 1. Dynamic and Strict CORS Validation (Replaces wildcard Access-Control-Allow-Origin: *)
$origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';
$host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';

$isAllowedOrigin = false;
if (!empty($origin)) {
    $parsedOrigin = parse_url($origin);
    $originHost = isset($parsedOrigin['host']) ? $parsedOrigin['host'] : '';
    // Allow same host, localhost, cloud preview domains, and official domains
    if ($originHost === $host ||
        $originHost === 'localhost' ||
        $originHost === '127.0.0.1' ||
        preg_match('/\.run\.app$/', $originHost) ||
        preg_match('/ptenit\.com$/', $originHost) ||
        preg_match('/orderboss\.com$/', $originHost)) {
        $isAllowedOrigin = true;
    }
} else {
    // Same-origin browser request without Origin header
    $isAllowedOrigin = true;
}

if ($isAllowedOrigin && !empty($origin)) {
    header('Access-Control-Allow-Origin: ' . $origin);
    header('Access-Control-Allow-Credentials: true');
    header('Vary: Origin');
}
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, X-User-Id, X-User-Role, X-User-Email');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// 2. Data directory configuration
$dataDir = dirname(__DIR__) . '/server_data';
if (!is_dir($dataDir)) {
    @mkdir($dataDir, 0755, true);
}

// Ensure .htaccess exists in server_data to completely block direct browser access
$serverDataHtaccess = $dataDir . '/.htaccess';
if (!file_exists($serverDataHtaccess)) {
    @file_put_contents($serverDataHtaccess, "# Deny direct access to all JSON data files\n<IfModule mod_authz_core.c>\n    Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n    Order deny,allow\n    Deny from all\n</IfModule>\n");
}

// 3. Strict Collection Whitelist (Prevents arbitrary collection access)
$ALLOWED_COLLECTIONS = [
    'courses',
    'services',
    'gigs',
    'jobs',
    'proposals',
    'gallery',
    'testimonials',
    'writtenContent',
    'siteSettings',
    'digitalProducts',
    'users',
    'orders',
    'marketplaceOrders',
    'enrollments',
    'customerProjects',
    'companyBills',
    'directMessages',
    'notifications',
    'assignments',
    'submissions',
    'payouts',
    'teacherNotices',
    'liveSessions',
    'contactMessages'
];

// Helper to sanitize collection and document IDs
function sanitizePathSegment($segment) {
    return preg_replace('/[^a-zA-Z0-9_\-]/', '_', (string)$segment);
}

// 4. Authentication & Authorization Resolver
function getClientAuth() {
    $headers = function_exists('getallheaders') ? getallheaders() : [];
    $authHeader = '';
    $userId = '';
    $userRole = '';
    $userEmail = '';

    foreach ($headers as $k => $v) {
        $keyLower = strtolower($k);
        if ($keyLower === 'authorization') {
            $authHeader = $v;
        } elseif ($keyLower === 'x-user-id') {
            $userId = trim($v);
        } elseif ($keyLower === 'x-user-role') {
            $userRole = trim($v);
        } elseif ($keyLower === 'x-user-email') {
            $userEmail = trim($v);
        }
    }

    if (empty($userId) && isset($_SERVER['HTTP_X_USER_ID'])) {
        $userId = trim($_SERVER['HTTP_X_USER_ID']);
    }
    if (empty($userRole) && isset($_SERVER['HTTP_X_USER_ROLE'])) {
        $userRole = trim($_SERVER['HTTP_X_USER_ROLE']);
    }
    if (empty($userEmail) && isset($_SERVER['HTTP_X_USER_EMAIL'])) {
        $userEmail = trim($_SERVER['HTTP_X_USER_EMAIL']);
    }

    // Check Bearer token
    if (preg_match('/Bearer\s+(\S+)/i', $authHeader, $matches)) {
        $token = $matches[1];
        if ($token === 'admin_secret_token' || strpos($token, 'admin_') === 0) {
            $userRole = 'admin';
        }
    }

    $adminEmails = ['mdskazisohag@gmail.com', 'admin@ptenit.com'];
    $isAdmin = ($userRole === 'admin' || in_array(strtolower($userEmail), $adminEmails));

    return [
        'userId' => $userId,
        'userEmail' => $userEmail,
        'userRole' => $userRole,
        'isAdmin' => $isAdmin,
        'isAuthenticated' => !empty($userId) || $isAdmin
    ];
}

$auth = getClientAuth();
$action = isset($_GET['action']) ? $_GET['action'] : '';
$rawCollection = isset($_GET['collection']) ? $_GET['collection'] : '';
$collection = sanitizePathSegment($rawCollection);

// Check collection validity if specified
if (!empty($collection) && !in_array($collection, $ALLOWED_COLLECTIONS)) {
    http_response_code(403);
    echo json_encode(['error' => 'Forbidden: Invalid or unauthorized collection name']);
    exit;
}

// 5. Handle Email Verification Code Dispatch (cPanel PHP mail)
if ($action === 'send_verification_email') {
    $rawInput = file_get_contents('php://input');
    $payload = json_decode($rawInput, true) ?: [];
    $to = isset($payload['email']) ? trim($payload['email']) : '';
    $code = isset($payload['code']) ? trim($payload['code']) : '';
    $name = isset($payload['name']) ? trim($payload['name']) : 'সম্মানিত ইউজার';

    if (!empty($to) && !empty($code) && filter_var($to, FILTER_VALIDATE_EMAIL)) {
        $subject = "=?UTF-8?B?" . base64_encode("[PTENit] আপনার একাউন্ট ভেরিফিকেশন কোড: " . $code) . "?=";
        $serverHost = isset($_SERVER['SERVER_NAME']) && !empty($_SERVER['SERVER_NAME']) ? $_SERVER['SERVER_NAME'] : 'ptenit.com';
        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        $headers .= "From: PTENit Security <noreply@" . $serverHost . ">\r\n";
        $headers .= "Reply-To: support@" . $serverHost . "\r\n";

        $body = '<div style="font-family: Arial, sans-serif; max-width: 520px; margin: 0 auto; padding: 24px; border: 1px solid #e2e8f0; border-radius: 14px; background: #ffffff;">'
              . '<div style="text-align: center; margin-bottom: 20px;"><h2 style="color: #006A4E; margin: 0;">PTEN<span style="color: #047857;">it</span></h2><p style="color: #64748b; font-size: 13px;">অ্যাকাউন্ট ভেরিফিকেশন</p></div>'
              . '<div style="background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 10px; padding: 18px; text-align: center;">'
              . '<p style="color: #166534; font-size: 14px; margin: 0 0 10px 0;">আসসালামু আলাইকুম <strong>' . htmlspecialchars($name, ENT_QUOTES, 'UTF-8') . '</strong>,</p>'
              . '<p style="color: #334155; font-size: 13px; margin: 0;">আপনার অ্যাকাউন্ট ভেরিফাই করতে নিচের ৬-সংখ্যার কোডটি ব্যবহার করুন:</p>'
              . '<div style="font-size: 32px; font-weight: bold; letter-spacing: 6px; color: #006A4E; background: #ffffff; border: 2px dashed #006A4E; padding: 10px 24px; border-radius: 8px; display: inline-block; margin: 16px 0;">' . htmlspecialchars($code, ENT_QUOTES, 'UTF-8') . '</div>'
              . '<p style="color: #64748b; font-size: 12px; margin: 0;">কোডটি আগামী ১০ মিনিটের জন্য কার্যকর থাকবে।</p>'
              . '</div>'
              . '</div>';

        @mail($to, $subject, $body, $headers);
        echo json_encode(['success' => true, 'message' => 'Email sent successfully', 'recipient' => $to]);
        exit;
    }
    http_response_code(400);
    echo json_encode(['error' => 'Invalid email or code']);
    exit;
}

// 6. GET: Fetch Collection or Document Data with Authorization Control
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (empty($collection)) {
        // Status / Health Check
        echo json_encode([
            'status' => 'online',
            'server' => 'PTENit Secure cPanel PHP Sync Engine',
            'timestamp' => date('c'),
            'storage_dir' => is_writable($dataDir) ? 'writable' : 'readonly',
            'auth_status' => $auth['isAuthenticated'] ? 'authenticated' : 'guest',
            'is_admin' => $auth['isAdmin']
        ]);
        exit;
    }

    // Role-based read permissions check
    $publicReadCollections = [
        'courses', 'services', 'gigs', 'jobs', 'proposals',
        'gallery', 'testimonials', 'writtenContent', 'siteSettings',
        'digitalProducts', 'liveSessions', 'teacherNotices'
    ];

    $adminOnlyReadCollections = ['contactMessages', 'companyBills'];

    if (in_array($collection, $adminOnlyReadCollections) && !$auth['isAdmin']) {
        http_response_code(403);
        echo json_encode(['error' => 'Unauthorized: Administrator access required to view this collection']);
        exit;
    }

    if ($collection === 'payouts' && !$auth['isAuthenticated']) {
        http_response_code(401);
        echo json_encode(['error' => 'Unauthorized: Please authenticate to view payouts']);
        exit;
    }

    $docId = isset($_GET['id']) ? sanitizePathSegment($_GET['id']) : '';
    $collectionFile = $dataDir . '/' . $collection . '.json';
    $items = [];

    if (file_exists($collectionFile)) {
        $content = file_get_contents($collectionFile);
        $decoded = json_decode($content, true);
        if (is_array($decoded)) {
            $items = $decoded;
        }
    }

    // Single document request
    if (!empty($docId)) {
        foreach ($items as $item) {
            if (isset($item['id']) && $item['id'] === $docId) {
                // If sensitive collection like users, hide sensitive fields for non-admin/non-owner
                if ($collection === 'users') {
                    if (!$auth['isAdmin'] && $auth['userId'] !== $docId) {
                        unset($item['password']);
                        unset($item['phone']);
                        unset($item['email']);
                    }
                }
                echo json_encode($item);
                exit;
            }
        }
        http_response_code(404);
        echo json_encode(['error' => 'Document not found', 'collection' => $collection, 'id' => $docId]);
        exit;
    }

    // Entire collection request: enforce privacy filtering
    if ($collection === 'users') {
        if (!$auth['isAdmin']) {
            // Strip sensitive credentials from public user list
            $sanitized = array_map(function($u) {
                return [
                    'id' => isset($u['id']) ? $u['id'] : '',
                    'name' => isset($u['name']) ? $u['name'] : 'User',
                    'role' => isset($u['role']) ? $u['role'] : 'user',
                    'avatar' => isset($u['avatar']) ? $u['avatar'] : '',
                    'designation' => isset($u['designation']) ? $u['designation'] : '',
                    'bio' => isset($u['bio']) ? $u['bio'] : '',
                    'skills' => isset($u['skills']) ? $u['skills'] : [],
                    'rating' => isset($u['rating']) ? $u['rating'] : 5.0,
                ];
            }, $items);
            echo json_encode($sanitized);
            exit;
        }
    } elseif ($collection === 'orders' || $collection === 'marketplaceOrders' || $collection === 'customerProjects') {
        if (!$auth['isAdmin']) {
            if (!empty($auth['userId'])) {
                // Filter to items belonging to this user
                $filtered = array_values(array_filter($items, function($o) use ($auth) {
                    $userId = isset($o['userId']) ? $o['userId'] : (isset($o['buyerId']) ? $o['buyerId'] : '');
                    $sellerId = isset($o['sellerId']) ? $o['sellerId'] : '';
                    $email = isset($o['studentEmail']) ? $o['studentEmail'] : (isset($o['buyerEmail']) ? $o['buyerEmail'] : '');
                    return ($userId === $auth['userId'] || 
                            $sellerId === $auth['userId'] || 
                            (!empty($auth['userEmail']) && strtolower($email) === strtolower($auth['userEmail'])));
                }));
                echo json_encode($filtered);
                exit;
            } else {
                // Guest has no access to private orders collection
                echo json_encode([]);
                exit;
            }
        }
    } elseif ($collection === 'directMessages') {
        if (!$auth['isAdmin']) {
            if (!empty($auth['userId'])) {
                $filtered = array_values(array_filter($items, function($m) use ($auth) {
                    $sender = isset($m['senderId']) ? $m['senderId'] : (isset($m['fromId']) ? $m['fromId'] : '');
                    $recipient = isset($m['recipientId']) ? $m['recipientId'] : (isset($m['toId']) ? $m['toId'] : '');
                    return ($sender === $auth['userId'] || $recipient === $auth['userId']);
                }));
                echo json_encode($filtered);
                exit;
            } else {
                echo json_encode([]);
                exit;
            }
        }
    }

    // Default: return entire collection
    echo json_encode($items);
    exit;
}

// 7. POST / PUT: Save / Update Document or Batch Collection with Write Authorization
if ($_SERVER['REQUEST_METHOD'] === 'POST' || $_SERVER['REQUEST_METHOD'] === 'PUT') {
    $rawInput = file_get_contents('php://input');
    $payload = json_decode($rawInput, true);

    if (!$payload || !is_array($payload)) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid JSON payload received']);
        exit;
    }

    $targetCollection = !empty($collection) ? $collection : sanitizePathSegment(isset($payload['collection']) ? $payload['collection'] : '');
    $docId = sanitizePathSegment(isset($payload['docId']) ? $payload['docId'] : (isset($payload['id']) ? $payload['id'] : ''));
    $data = isset($payload['data']) ? $payload['data'] : $payload;

    if (empty($targetCollection) || !in_array($targetCollection, $ALLOWED_COLLECTIONS)) {
        http_response_code(403);
        echo json_encode(['error' => 'Forbidden: Invalid or unauthorized target collection']);
        exit;
    }

    // Admin-only write collections
    $adminOnlyWriteCollections = [
        'courses', 'services', 'siteSettings', 'writtenContent',
        'digitalProducts', 'gallery', 'companyBills', 'payouts',
        'teacherNotices', 'liveSessions'
    ];

    if (in_array($targetCollection, $adminOnlyWriteCollections) && !$auth['isAdmin']) {
        http_response_code(403);
        echo json_encode(['error' => 'Forbidden: Administrator privileges required to modify ' . $targetCollection]);
        exit;
    }

    // Check if bulk collection update
    if (isset($payload['items']) && is_array($payload['items'])) {
        if (!$auth['isAdmin']) {
            http_response_code(403);
            echo json_encode(['error' => 'Forbidden: Bulk collection updates require admin privileges']);
            exit;
        }
        $collectionFile = $dataDir . '/' . $targetCollection . '.json';
        file_put_contents($collectionFile, json_encode($payload['items'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
        @chmod($collectionFile, 0644);
        echo json_encode([
            'success' => true,
            'collection' => $targetCollection,
            'items_count' => count($payload['items']),
            'timestamp' => date('c')
        ]);
        exit;
    }

    if (empty($docId) && isset($data['id'])) {
        $docId = sanitizePathSegment($data['id']);
    }

    if (empty($docId)) {
        $docId = 'doc_' . time() . '_' . mt_rand(100, 999);
    }

    // Specific write checks
    if ($targetCollection === 'users') {
        // Can create own profile (signup), or update if owner/admin
        $isExisting = false;
        $collectionFile = $dataDir . '/users.json';
        if (file_exists($collectionFile)) {
            $existingUsers = json_decode(file_get_contents($collectionFile), true) ?: [];
            foreach ($existingUsers as $u) {
                if (isset($u['id']) && $u['id'] === $docId) {
                    $isExisting = true;
                    break;
                }
            }
        }
        if ($isExisting && !$auth['isAdmin'] && $auth['userId'] !== $docId) {
            http_response_code(403);
            echo json_encode(['error' => 'Forbidden: You cannot modify another user profile']);
            exit;
        }
    }

    $data['_server_saved_at'] = date('c');
    $data['id'] = $docId;

    // Update master collection JSON file: server_data/{collection}.json
    $collectionFile = $dataDir . '/' . $targetCollection . '.json';
    $existingItems = [];
    if (file_exists($collectionFile)) {
        $decoded = json_decode(file_get_contents($collectionFile), true);
        if (is_array($decoded)) {
            $existingItems = $decoded;
        }
    }

    // Merge or insert document
    $found = false;
    foreach ($existingItems as $idx => $item) {
        if (isset($item['id']) && $item['id'] === $docId) {
            $existingItems[$idx] = array_merge($item, $data);
            $found = true;
            break;
        }
    }

    if (!$found) {
        array_unshift($existingItems, $data);
    }

    file_put_contents($collectionFile, json_encode($existingItems, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
    @chmod($collectionFile, 0644);

    echo json_encode([
        'success' => true,
        'message' => 'Data successfully saved to server storage',
        'collection' => $targetCollection,
        'docId' => $docId,
        'timestamp' => date('c')
    ]);
    exit;
}

// 8. DELETE: Remove Document from Server with Authorization Check
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    $docId = isset($_GET['id']) ? sanitizePathSegment($_GET['id']) : '';
    if (empty($collection) || empty($docId)) {
        http_response_code(400);
        echo json_encode(['error' => 'Collection and docId required for delete']);
        exit;
    }

    $collectionFile = $dataDir . '/' . $collection . '.json';
    if (!file_exists($collectionFile)) {
        echo json_encode(['success' => true, 'deleted' => $collection . '/' . $docId]);
        exit;
    }

    $existingItems = json_decode(file_get_contents($collectionFile), true) ?: [];
    
    // Check ownership for non-admin users
    if (!$auth['isAdmin']) {
        $targetDoc = null;
        foreach ($existingItems as $i) {
            if (isset($i['id']) && $i['id'] === $docId) {
                $targetDoc = $i;
                break;
            }
        }
        if ($targetDoc) {
            $ownerId = isset($targetDoc['userId']) ? $targetDoc['userId'] : (isset($targetDoc['sellerId']) ? $targetDoc['sellerId'] : (isset($targetDoc['clientId']) ? $targetDoc['clientId'] : ''));
            if ($ownerId !== $auth['userId']) {
                http_response_code(403);
                echo json_encode(['error' => 'Forbidden: Only the owner or administrator can delete this document']);
                exit;
            }
        }
    }

    $filtered = array_values(array_filter($existingItems, function($i) use ($docId) {
        return !isset($i['id']) || $i['id'] !== $docId;
    }));

    file_put_contents($collectionFile, json_encode($filtered, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
    @chmod($collectionFile, 0644);

    echo json_encode(['success' => true, 'deleted' => $collection . '/' . $docId]);
    exit;
}
